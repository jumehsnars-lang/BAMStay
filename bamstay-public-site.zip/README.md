# BAMStay (PHP / XAMPP)

This is the local PHP version of the BAMStay site. It serves plain PHP-rendered
HTML, local CSS, and vanilla JavaScript; no Node.js, frontend framework, or
build step is needed to run it. Property and bed photos remain regular files in
`assets/images/` and are never saved in MySQL.

## XAMPP setup

1. Copy this whole `BAMStay` folder into your XAMPP web root. For the folder
   layout used by this project, that is:

   ```text
   C:\xampp\htdocs\bamstay\BAMStay
   ```

   If your XAMPP installation is in a different directory, preserve the
   `bamstay\BAMStay` folders under its `htdocs` directory.
2. Open the XAMPP Control Panel and start **Apache** and **MySQL**.
3. Open phpMyAdmin at `http://localhost/phpmyadmin`.
4. Select **Import**, choose `database.sql` from this project folder, and run
   the import. The script creates the `bamstay` database and the `inquiries`
   table.
5. Open [`config.php`](./config.php). Its defaults match a standard local XAMPP
   setup (`127.0.0.1`, port `3306`, database `bamstay`, user `root`, blank
   password). If your MySQL credentials differ, change those values there.
6. Confirm the PHP `PDO_MySQL` and `mbstring` extensions are enabled in the
   `php.ini` used by Apache. Restart Apache after changing `php.ini`.
7. Open the site at:

   **http://localhost/bamstay/BAMStay/**

## Inquiry submissions

The inquiry form validates and normalizes input on the server, checks a
session-based CSRF token, confirms a requested bed is currently available,
then inserts the inquiry with a PDO prepared statement. A success message is
shown only after MySQL confirms that the row was inserted. If MySQL is stopped,
the database is missing, or saving fails, the form displays an error instead.

Submitted inquiries are available in phpMyAdmin under
`bamstay.inquiries`. Do not put photos or other image data in this table.
Room, bedspace, facility, and gallery content is structured in
[`data/site.php`](./data/site.php) and can later be loaded from a database
without changing the page templates.

## Project layout

- `index.php` handles requests, server-side validation, and form submissions.
- `data/site.php` holds rooms, bedspaces, rates, facilities, and gallery data.
- `partials/` contains the page sections, navigation, footer, and dialogs.
- `assets/css/` contains the site stylesheet and the bundled compiled styles
  matching the current BAMStay design.
- `assets/js/site.js` implements the responsive menu, room carousel and modal,
  bed selection, inquiry preview, and continuous gallery carousel.
- `assets/images/` contains the existing property and bed photos.
- `database.sql` creates the MySQL database and inquiry table.
