<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="BAMStay: safe, comfortable ladies' dormitory and bedspace rooms. View rooms, facilities and send an inquiry.">
    <meta property="og:title" content="BAMStay — More Than a Room, It's Your Home">
    <meta property="og:description" content="Safe, welcoming ladies' dormitory and bedspace accommodation. Browse rooms and inquire today.">
    <meta property="og:type" content="website">
    <title>BAMStay — Ladies' Dormitory &amp; Bedspace Accommodation</title>
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,500&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/current-site.css">
    <link rel="stylesheet" href="assets/css/site.css">
</head>
<body>
